sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("MM.zbammdocument.controller.App", {
        onInit() {
        }
      });
    }
  );
  
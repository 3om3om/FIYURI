sap.ui.define([
	"MM/zba_mmdocument/test/unit/controller/Main.controller"
], function () {
	"use strict";
});

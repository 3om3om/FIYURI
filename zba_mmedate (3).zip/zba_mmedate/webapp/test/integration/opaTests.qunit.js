/* global QUnit */

sap.ui.require(["MM/zbammedate/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});

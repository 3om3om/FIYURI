sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/date/UI5Date",
    "sap/ui/unified/library",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment",
  ],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (
    Controller,
    JSONModel,
    UI5Date,
    unifiedLibrary,
    Filter,
    FilterOperator,
    Fragment
  ) {
    "use strict";

    var CalendarDayType = unifiedLibrary.CalendarDayType;

    return Controller.extend("MM.zbammedate.controller.Main", {
      DateFormatter: function (oDate) {
        // 바인딩된 값이 oDate로 넣어짐
        return UI5Date.getInstance(oDate); // 바인딩된 값을 UI5Date 형식으로 변환 후 리턴
      },

      onInit: function () {
        var oDatas = {
          list: [{ MTART: "원자재" }, { MTART: "부자재" }],
        };

        // json data를 포함한 json model 생성
        var oModel = new JSONModel(oDatas);

        // json model을 뷰에서 사용할 수 있도록 생성 ("view"는 모델 이름)
        this.getView().setModel(oModel, "view");
      },

      onSearch: function () {
        var oCalendar = this.byId("SPC1");
        var oComcobox = this.byId("idCombobox").getValue();
        var aFilter = []; // undefined

        if (oComcobox) {
          aFilter.push(
            new Filter({
              path: "MTART",
              operator: "EQ",
              value1: oComcobox,
            })
          );
        }

        oCalendar
          .getBinding("appointments")
          .filter((aFilter.length && aFilter) || undefined);
      },

      onDialog: function (oEvent) {
        // var sPath = oEvent.mParameters.appointment.mProperties.title;
        // var sPath = oEvent.getSource().mBindingInfos.appointments;

        var sPath = oEvent
          .getParameters()
          .appointment._getBindingContext()
          .getProperty().EBELN;

        var oDialog = sap.ui.getCore().setModel().byId("idDialog");
        var oModel = this.getView().getModel();

        // ODataModel.getProperty(경로) 해서 해당 Row의 전체 데이터 가져오기
        // => 전체데이터.OrderID를 통해 OrderID 값을 얻을 수 있다.
        // var oItem = oModel.getProperty(sPath);
        // var oItem = oModel.getKey(sPath);

        if (oDialog) {
          oDialog.open();
        } else {
          Fragment.load({
            name: "MM.zbammedate.view.Fragment.Detail",
            type: "XML",
            controller: this,
          }).then(function (oDialog) {
            debugger;
            sap.ui
              .getCore()
              .byId("idPOList")
              .bindElement(`/ZBA_MMT100Set'(32000006)'`);
            // oDialog.setModel(oItem);
            oDialog.open();
          });
        }
      },
      onClose: function (oEvent) {
        /*
            getSource() : 이벤트를 일으킨 객체
            getParameters() : 이벤트 관련 정보 
        */
        // var oDialog = sap.ui.getcore().byId("idDialog");
        var oButton = oEvent.getSource();
        var oDialog = oButton.getParent();

        debugger;

        oDialog.close();
      },
    });
  }
);

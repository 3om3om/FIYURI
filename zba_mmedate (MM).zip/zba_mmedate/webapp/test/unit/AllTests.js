sap.ui.define([
	"MM/zba_mmedate/test/unit/controller/Main.controller"
], function () {
	"use strict";
});

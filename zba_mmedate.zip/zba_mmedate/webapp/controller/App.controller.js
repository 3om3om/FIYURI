sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("MM.zbammedate.controller.App", {
        onInit() {
        }
      });
    }
  );
  
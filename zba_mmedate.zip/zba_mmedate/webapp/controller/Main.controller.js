sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/date/UI5Date",
    "sap/ui/unified/library",
  ],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (Controller, JSONModel, UI5Date, unifiedLibrary) {
    "use strict";

    var CalendarDayType = unifiedLibrary.CalendarDayType;

    return Controller.extend("MM.zbammedate.controller.Main", {
      onInit: function () {
        var oDatas = {
          list: [{ MTART: "원자재" }, { MTART: "부자재" }],
        };

        // json data를 포함한 json model 생성
        var oModel = new JSONModel(oDatas);

        // json model을 뷰에서 사용할 수 있도록 생성 ("view"는 모델 이름)
        this.getView().setModel(oModel, "view");

        var oModel2 = new JSONModel();
        oModel2.setData({
          startDate: UI5Date.getInstance("2023", "10", "1"),
          appointments: [
            // {
            //   title: "EBELN",
            //   type: CalendarDayType.Type05,
            //   startDate: UI5Date.getInstance("DDATE"),
            //   endDate: UI5Date.getInstance("DDATE"),
            // },
            {
              title: "Discussion of the plan",
              type: CalendarDayType.Type01,
              startDate: UI5Date.getInstance("2023", "10", "9", "6", "0"),
              endDate: UI5Date.getInstance("2023", "10", "9", "7", "9"),
            },
          ],
        });
        this.getView().setModel(oModel2);

        oModel2 = new JSONModel();
        oModel2.setData({ allDay: false });
        this.getView().setModel(oModel2, "allDay");
      },
    });
  }
);
